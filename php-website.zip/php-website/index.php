<?php
// index.php - Main entry point
$page = isset($_GET['page']) ? $_GET['page'] : 'home';
$allowed_pages = ['home', 'about', 'services', 'contact'];

if (!in_array($page, $allowed_pages)) {
    $page = 'home';
}

// Handle contact form submission
$form_message = '';
$form_success = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_form'])) {
    $name    = htmlspecialchars(trim($_POST['name'] ?? ''));
    $email   = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
    $subject = htmlspecialchars(trim($_POST['subject'] ?? ''));
    $message = htmlspecialchars(trim($_POST['message'] ?? ''));

    if ($name && $email && $subject && $message) {
        // In production, use mail() or an SMTP library here
        $form_success = true;
        $form_message = "Thank you, {$name}! Your message has been received. I'll get back to you shortly.";
    } else {
        $form_message = "Please fill in all fields with valid information.";
    }
}

require_once 'includes/head.php';
require_once 'includes/nav.php';

switch ($page) {
    case 'about':
        require_once 'pages/about.php';
        break;
    case 'services':
        require_once 'pages/services.php';
        break;
    case 'contact':
        require_once 'pages/contact.php';
        break;
    default:
        require_once 'pages/home.php';
        break;
}

require_once 'includes/footer.php';
?>
