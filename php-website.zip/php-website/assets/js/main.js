/**
 * main.js — Portfolio Interactive Scripts
 * Handles: nav scroll, mobile menu, scroll reveal, terminal animation
 */

(function () {
  'use strict';

  /* =============================================
     1. NAVIGATION — Scroll + Mobile Toggle
     ============================================= */
  const header    = document.getElementById('site-header');
  const navToggle = document.getElementById('nav-toggle');
  const navLinks  = document.getElementById('nav-links');
  const navOverlay = document.getElementById('nav-overlay');

  // Scroll → add .scrolled class
  if (header) {
    const onScroll = () => {
      if (window.scrollY > 20) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll(); // Run immediately
  }

  // Mobile nav toggle
  function openNav() {
    navLinks?.classList.add('is-open');
    navOverlay?.classList.add('is-open');
    navToggle?.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }
  function closeNav() {
    navLinks?.classList.remove('is-open');
    navOverlay?.classList.remove('is-open');
    navToggle?.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }

  navToggle?.addEventListener('click', () => {
    const isOpen = navLinks?.classList.contains('is-open');
    isOpen ? closeNav() : openNav();
  });
  navOverlay?.addEventListener('click', closeNav);

  // Close nav on nav-link click (mobile)
  navLinks?.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', closeNav);
  });

  // Keyboard close on Escape
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeNav();
  });

  /* =============================================
     2. SCROLL REVEAL — Intersection Observer
     ============================================= */
  const revealEls = document.querySelectorAll(
    '.service-card, .role-card, .value-card, .process-step, .cert-chip, ' +
    '.about-story, .ai-future-inner, .contact-grid, .cta-banner-inner, ' +
    '.service-full-grid, .hero-stats, .about-snippet-inner'
  );

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, idx) => {
      if (entry.isIntersecting) {
        entry.target.style.animationDelay = `${idx * 0.06}s`;
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });

  revealEls.forEach(el => {
    el.classList.add('reveal');
    revealObserver.observe(el);
  });

  /* =============================================
     3. ACTIVE NAV LINK — Highlight on scroll
     ============================================= */
  const sections = document.querySelectorAll('section[id]');
  if (sections.length) {
    const sectionObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('nav-link--active');
          });
        }
      });
    }, { threshold: 0.3 });
    sections.forEach(s => sectionObserver.observe(s));
  }

  /* =============================================
     4. TERMINAL — Typewriter Animation
     ============================================= */
  const terminalBody = document.getElementById('terminal-body');
  if (terminalBody) {
    const lines = terminalBody.querySelectorAll('.terminal-line');
    lines.forEach((line, i) => {
      line.style.opacity = '0';
      line.style.transform = 'translateX(-8px)';
      line.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    });

    const termObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          lines.forEach((line, i) => {
            setTimeout(() => {
              line.style.opacity = '1';
              line.style.transform = 'translateX(0)';
            }, i * 250);
          });
          termObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });

    termObserver.observe(terminalBody);
  }

  /* =============================================
     5. CONTACT FORM — Client-side validation
     ============================================= */
  const contactForm   = document.getElementById('contact-form');
  const submitBtn     = document.getElementById('contact-submit');

  if (contactForm && submitBtn) {
    contactForm.addEventListener('submit', function (e) {
      const inputs = contactForm.querySelectorAll('[required]');
      let valid = true;

      inputs.forEach(input => {
        input.classList.remove('form-input--error');
        if (!input.value.trim()) {
          input.classList.add('form-input--error');
          valid = false;
        }
        if (input.type === 'email' && input.value.trim()) {
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(input.value.trim())) {
            input.classList.add('form-input--error');
            valid = false;
          }
        }
      });

      if (!valid) {
        e.preventDefault();
        const firstError = contactForm.querySelector('.form-input--error');
        firstError?.focus();
        firstError?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else {
        submitBtn.innerHTML = '<i class="ph ph-spinner"></i> Sending...';
        submitBtn.disabled = true;
      }
    });
  }

  /* =============================================
     6. SMOOTH SCROLL for anchor links
     ============================================= */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        const navH = header ? header.offsetHeight : 70;
        const top  = target.getBoundingClientRect().top + window.scrollY - navH - 16;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    });
  });

  /* =============================================
     7. TECH BADGE hover glow on avatar badges
     ============================================= */
  document.querySelectorAll('.tech-badge').forEach(badge => {
    badge.addEventListener('mouseenter', () => {
      badge.style.borderColor = 'rgba(59, 130, 246, 0.5)';
      badge.style.boxShadow   = '0 0 16px rgba(59, 130, 246, 0.2)';
    });
    badge.addEventListener('mouseleave', () => {
      badge.style.borderColor = '';
      badge.style.boxShadow   = '';
    });
  });

  /* =============================================
     8. Form input error state clear
     ============================================= */
  document.querySelectorAll('.form-input').forEach(input => {
    input.addEventListener('input', () => {
      input.classList.remove('form-input--error');
    });
  });

})();
