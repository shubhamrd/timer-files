<?php
$page_titles = [
    'home' => 'Shubham D. | Cloud & Containerization Corporate Trainer',
    'about' => 'About | Shubham D.',
    'services' => 'Services | Shubham D.',
    'contact' => 'Contact | Shubham D.',
];
$meta_descs = [
    'home' => 'Corporate Technical Trainer, Cloud Solution Architect Associate, and Microsoft Copilot Moderator specializing in AWS, GCP, Azure, Docker, Kubernetes, and AI Infrastructure.',
    'about' => 'Learn more about Shubham D. — Software Engineer turned Corporate Trainer based in Sangamner, Maharashtra.',
    'services' => 'Expert training services in Cloud Platforms, Containerization, Curriculum Design, and AI Infrastructure.',
    'contact' => 'Book a training session or get in touch with Shubham D.',
];
$current_title = $page_titles[$page] ?? $page_titles['home'];
$current_desc = $meta_descs[$page] ?? $meta_descs['home'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= $current_desc ?>">
    <meta name="author" content="Shubham D.">
    <meta property="og:title" content="<?= $current_title ?>">
    <meta property="og:description" content="<?= $current_desc ?>">
    <meta property="og:url" content="https://shubhamd.com">
    <meta property="og:type" content="website">
    <title>
        <?= $current_title ?>
    </title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;700&display=swap"
        rel="stylesheet">
    <!-- Phosphor Icons -->
    <script src="https://unpkg.com/@phosphor-icons/web@2.1.1/src/index.js" defer></script>
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body data-page="<?= $page ?>">