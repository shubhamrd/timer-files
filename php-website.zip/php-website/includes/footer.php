<?php $year = date('Y'); ?>
<footer class="site-footer" id="site-footer">
    <div class="footer-container">
        <div class="footer-brand">
            <a href="?page=home" class="nav-logo footer-logo">
                <span class="logo-bracket">&lt;</span>
                <span class="logo-name">SD</span>
                <span class="logo-bracket">/&gt;</span>
            </a>
            <p class="footer-tagline">Cloud · Containers · AI Infrastructure</p>
        </div>
        <div class="footer-links">
            <div class="footer-col">
                <h4 class="footer-heading">Navigate</h4>
                <ul role="list">
                    <li><a href="?page=home">Home</a></li>
                    <li><a href="?page=about">About</a></li>
                    <li><a href="?page=services">Services</a></li>
                    <li><a href="?page=contact">Contact</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4 class="footer-heading">Expertise</h4>
                <ul role="list">
                    <li><a href="?page=services#cloud">Cloud Platforms</a></li>
                    <li><a href="?page=services#containers">Containerization</a></li>
                    <li><a href="?page=services#curriculum">Curriculum Design</a></li>
                    <li><a href="?page=services#ai">AI Infrastructure</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4 class="footer-heading">Connect</h4>
                <ul role="list">
                    <li>
                        <a href="https://linkedin.com/in/shubhamd" target="_blank" rel="noopener noreferrer"
                            id="footer-linkedin">
                            <i class="ph ph-linkedin-logo"></i> LinkedIn
                        </a>
                    </li>
                    <li>
                        <a href="https://github.com/shubhamd" target="_blank" rel="noopener noreferrer"
                            id="footer-github">
                            <i class="ph ph-github-logo"></i> GitHub
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy;
            <?= $year ?> Shubham D. All rights reserved. Built with PHP 8.4.
        </p>
        <p class="footer-location"><i class="ph ph-map-pin"></i> Sangamner, Maharashtra, India</p>
    </div>
</footer>
<script src="assets/js/main.js"></script>
</body>

</html>