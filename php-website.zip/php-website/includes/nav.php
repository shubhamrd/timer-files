<?php
$nav_links = [
    'home' => 'Home',
    'about' => 'About',
    'services' => 'Services',
    'contact' => 'Contact',
];
?>
<header class="site-header" id="site-header">
    <nav class="nav-container">
        <a href="?page=home" class="nav-logo" id="nav-logo">
            <span class="logo-bracket">&lt;</span>
            <span class="logo-name">SD</span>
            <span class="logo-bracket">/&gt;</span>
        </a>
        <button class="nav-toggle" id="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">
            <span class="hamburger-line"></span>
            <span class="hamburger-line"></span>
            <span class="hamburger-line"></span>
        </button>
        <ul class="nav-links" id="nav-links" role="list">
            <?php foreach ($nav_links as $key => $label): ?>
                <li>
                    <a href="?page=<?= $key ?>" class="nav-link <?= $page === $key ? 'nav-link--active' : '' ?>"
                        id="nav-<?= $key ?>">
                        <?= $label ?>
                    </a>
                </li>
            <?php endforeach; ?>
            <li>
                <a href="?page=contact" class="btn btn-primary btn-sm" id="nav-cta">
                    Book a Session
                </a>
            </li>
        </ul>
    </nav>
</header>
<div class="nav-overlay" id="nav-overlay"></div>