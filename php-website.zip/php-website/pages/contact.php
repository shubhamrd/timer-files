<?php // pages/contact.php ?>
<section class="page-hero" id="contact-hero">
    <div class="hero-bg-grid"></div>
    <div class="container">
        <div class="section-label">CONTACT</div>
        <h1 class="page-hero-title">Let's Start the Conversation</h1>
        <p class="page-hero-sub">Book a session, ask a question, or simply say hello.</p>
    </div>
</section>

<section class="section contact-section" id="contact-section">
    <div class="container">
        <div class="contact-grid">
            <!-- Contact Info -->
            <div class="contact-info" id="contact-info">
                <div class="section-label">GET IN TOUCH</div>
                <h2 class="section-title" style="font-size:2rem">Book a Training Session</h2>
                <p class="section-body">
                    Whether you're looking for a single workshop, a multi-week program, or custom curriculum
                    design — reach out and let's explore what we can build together.
                </p>

                <div class="contact-details">
                    <div class="contact-detail-item">
                        <div class="contact-detail-icon">
                            <i class="ph ph-map-pin"></i>
                        </div>
                        <div>
                            <strong>Location</strong>
                            <p>Sangamner, Maharashtra, India</p>
                        </div>
                    </div>
                    <div class="contact-detail-item">
                        <div class="contact-detail-icon">
                            <i class="ph ph-globe"></i>
                        </div>
                        <div>
                            <strong>Website</strong>
                            <p><a href="https://shubhamd.com" target="_blank">shubhamd.com</a></p>
                        </div>
                    </div>
                </div>

                <div class="contact-social-row">
                    <a href="https://linkedin.com/in/shubhamd" target="_blank" rel="noopener" class="social-card"
                        id="contact-linkedin">
                        <i class="ph ph-linkedin-logo"></i>
                        <div>
                            <strong>LinkedIn</strong>
                            <span>Connect professionally</span>
                        </div>
                    </a>
                    <a href="https://github.com/shubhamd" target="_blank" rel="noopener" class="social-card"
                        id="contact-github">
                        <i class="ph ph-github-logo"></i>
                        <div>
                            <strong>GitHub</strong>
                            <span>Explore my repos</span>
                        </div>
                    </a>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="contact-form-wrap" id="contact-form-wrap">
                <?php if (!empty($form_message)): ?>
                    <div class="form-alert form-alert--<?= $form_success ? 'success' : 'error' ?>" id="form-alert">
                        <i class="ph <?= $form_success ? 'ph-check-circle' : 'ph-warning-circle' ?>"></i>
                        <?= $form_message ?>
                    </div>
                <?php endif; ?>

                <?php if (!$form_success): ?>
                    <form method="POST" action="?page=contact" class="contact-form" id="contact-form" novalidate>
                        <input type="hidden" name="contact_form" value="1">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">Full Name <span class="required">*</span></label>
                                <input type="text" name="name" id="name" class="form-input" placeholder="Jane Smith"
                                    value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required autocomplete="name">
                            </div>
                            <div class="form-group">
                                <label for="email">Email Address <span class="required">*</span></label>
                                <input type="email" name="email" id="email" class="form-input"
                                    placeholder="jane@company.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                                    required autocomplete="email">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="subject">Subject / Training Area <span class="required">*</span></label>
                            <select name="subject" id="subject" class="form-input form-select" required>
                                <option value="" disabled <?= empty($_POST['subject']) ? 'selected' : '' ?>>Select a topic...
                                </option>
                                <option value="Cloud Training (AWS/GCP/Azure)" <?= ($_POST['subject'] ?? '') === 'Cloud Training (AWS/GCP/Azure)' ? 'selected' : '' ?>>Cloud Training (AWS/GCP/Azure)
                                </option>
                                <option value="Containerization (Docker/Kubernetes)" <?= ($_POST['subject'] ?? '') === 'Containerization (Docker/Kubernetes)' ? 'selected' : '' ?>>Containerization
                                    (Docker/Kubernetes)</option>
                                <option value="Curriculum Design" <?= ($_POST['subject'] ?? '') === 'Curriculum Design' ? 'selected' : '' ?>>Curriculum Design</option>
                                <option value="AI Infrastructure / MLOps" <?= ($_POST['subject'] ?? '') === 'AI Infrastructure / MLOps' ? 'selected' : '' ?>>AI Infrastructure / MLOps (Early
                                    Access)</option>
                                <option value="General Inquiry" <?= ($_POST['subject'] ?? '') === 'General Inquiry' ? 'selected' : '' ?>>General Inquiry</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="company">Company / Organization <span
                                    class="form-optional">(optional)</span></label>
                            <input type="text" name="company" id="company" class="form-input" placeholder="Acme Corp"
                                value="<?= htmlspecialchars($_POST['company'] ?? '') ?>" autocomplete="organization">
                        </div>
                        <div class="form-group">
                            <label for="message">Message <span class="required">*</span></label>
                            <textarea name="message" id="message" class="form-input form-textarea"
                                placeholder="Tell me about your team size, current skill level, goals, and preferred timeline..."
                                rows="5" required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary btn-full" id="contact-submit">
                            <i class="ph ph-paper-plane-tilt"></i>
                            Send Message
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>