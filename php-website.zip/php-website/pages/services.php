<?php // pages/services.php ?>
<section class="page-hero" id="services-hero">
    <div class="hero-bg-grid"></div>
    <div class="container">
        <div class="section-label">SERVICES</div>
        <h1 class="page-hero-title">Training That Transforms Teams</h1>
        <p class="page-hero-sub">Hands-on, lab-driven programs designed to build real-world cloud and container
            proficiency.</p>
    </div>
</section>

<!-- Cloud Platforms -->
<section class="section service-full" id="cloud">
    <div class="container">
        <div class="service-full-grid">
            <div class="service-full-visual">
                <div class="service-icon-large service-icon-large--blue">
                    <i class="ph ph-cloud-lightning"></i>
                </div>
                <div class="service-tech-list">
                    <?php foreach (['AWS', 'Google Cloud', 'Microsoft Azure'] as $t): ?>
                        <span class="tech-pill">
                            <?= $t ?>
                        </span>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="service-full-content">
                <div class="section-label" style="color: var(--accent-blue);">PILLAR 01</div>
                <h2 class="section-title">Cloud Platforms</h2>
                <p class="section-body">
                    Comprehensive training across the three major hyperscalers — AWS, GCP, and Microsoft Azure.
                    From foundational concepts to advanced architectural patterns, sessions are designed to
                    build genuine expertise, not just certification familiarity.
                </p>
                <ul class="service-feature-list">
                    <li><i class="ph ph-check-circle"></i> IAM, VPC, Networking fundamentals</li>
                    <li><i class="ph ph-check-circle"></i> Compute, Storage &amp; Database services</li>
                    <li><i class="ph ph-check-circle"></i> Serverless architectures (Lambda, Cloud Functions)</li>
                    <li><i class="ph ph-check-circle"></i> Cost optimization strategies</li>
                    <li><i class="ph ph-check-circle"></i> Multi-cloud governance and compliance</li>
                    <li><i class="ph ph-check-circle"></i> Hands-on lab environments for every module</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- Containerization -->
<section class="section service-full service-full--alt" id="containers">
    <div class="container">
        <div class="service-full-grid">
            <div class="service-full-content">
                <div class="section-label" style="color: var(--accent-teal);">PILLAR 02</div>
                <h2 class="section-title">Containerization &amp; Orchestration</h2>
                <p class="section-body">
                    Docker and Kubernetes are the backbone of modern DevOps. This pillar takes teams from
                    basic containerization concepts to production-scale orchestration, including security
                    hardening, observability, and GitOps workflows.
                </p>
                <ul class="service-feature-list">
                    <li><i class="ph ph-check-circle"></i> Docker fundamentals &amp; best practices</li>
                    <li><i class="ph ph-check-circle"></i> Kubernetes architecture deep-dive</li>
                    <li><i class="ph ph-check-circle"></i> Helm charts &amp; package management</li>
                    <li><i class="ph ph-check-circle"></i> CI/CD integration (GitHub Actions, Jenkins)</li>
                    <li><i class="ph ph-check-circle"></i> Container security &amp; image scanning</li>
                    <li><i class="ph ph-check-circle"></i> Service mesh (Istio, Linkerd) intro</li>
                </ul>
            </div>
            <div class="service-full-visual">
                <div class="service-icon-large service-icon-large--teal">
                    <i class="ph ph-package"></i>
                </div>
                <div class="service-tech-list">
                    <?php foreach (['Docker', 'Kubernetes', 'Helm', 'Istio'] as $t): ?>
                        <span class="tech-pill">
                            <?= $t ?>
                        </span>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Curriculum Design -->
<section class="section service-full" id="curriculum">
    <div class="container">
        <div class="service-full-grid">
            <div class="service-full-visual">
                <div class="service-icon-large service-icon-large--purple">
                    <i class="ph ph-book-open-text"></i>
                </div>
                <div class="service-tech-list">
                    <?php foreach (['Lab Guides', 'Assessments', 'LMS-Ready', 'Custom Pace'] as $t): ?>
                        <span class="tech-pill">
                            <?= $t ?>
                        </span>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="service-full-content">
                <div class="section-label" style="color: var(--accent-purple);">PILLAR 03</div>
                <h2 class="section-title">Curriculum Design</h2>
                <p class="section-body">
                    Great training starts with great curriculum. I design tailored lab guides, step-by-step
                    instructional materials, and corporate evaluation frameworks that match your team's maturity
                    and organizational objectives.
                </p>
                <ul class="service-feature-list">
                    <li><i class="ph ph-check-circle"></i> Custom lab guide development</li>
                    <li><i class="ph ph-check-circle"></i> Hands-on, step-by-step instruction design</li>
                    <li><i class="ph ph-check-circle"></i> Corporate competency assessments</li>
                    <li><i class="ph ph-check-circle"></i> LMS-ready content packaging</li>
                    <li><i class="ph ph-check-circle"></i> Trainer-of-trainers (ToT) programs</li>
                    <li><i class="ph ph-check-circle"></i> Post-training evaluation &amp; skill benchmarking</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- AI Infrastructure -->
<section class="section service-full service-full--alt ai-section" id="ai">
    <div class="ai-future-glow ai-glow-sm"></div>
    <div class="container">
        <div class="service-full-grid">
            <div class="service-full-content">
                <div class="section-label" style="color: var(--accent-orange);">UPCOMING FOCUS</div>
                <h2 class="section-title">AI Infrastructure &amp; MLOps <span class="coming-soon-tag">Coming Soon</span>
                </h2>
                <p class="section-body">
                    The convergence of container orchestration and AI workloads is reshaping infrastructure.
                    I'm researching and building the next generation of training modules that empower teams
                    to run LLMs, manage ML pipelines, and build agentic AI systems on Kubernetes.
                </p>
                <ul class="service-feature-list">
                    <li><i class="ph ph-lightning"></i> MLOps pipelines on Kubernetes</li>
                    <li><i class="ph ph-lightning"></i> Deploying &amp; serving LLMs with Docker/K8s</li>
                    <li><i class="ph ph-lightning"></i> Agentic AI system design &amp; orchestration</li>
                    <li><i class="ph ph-lightning"></i> GPU resource scheduling in Kubernetes</li>
                    <li><i class="ph ph-lightning"></i> AI workload observability &amp; cost control</li>
                    <li><i class="ph ph-lightning"></i> Responsible AI governance in enterprise settings</li>
                </ul>
                <a href="?page=contact" class="btn btn-primary" id="ai-interest-cta">
                    <i class="ph ph-lightning"></i> Register Interest
                </a>
            </div>
            <div class="service-full-visual">
                <div class="service-icon-large service-icon-large--orange">
                    <i class="ph ph-brain"></i>
                </div>
                <div class="service-tech-list">
                    <?php foreach (['MLOps', 'LLMOps', 'Agentic AI', 'GPU K8s'] as $t): ?>
                        <span class="tech-pill">
                            <?= $t ?>
                        </span>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Process -->
<section class="section process-section" id="process">
    <div class="container">
        <div class="section-header centered">
            <div class="section-label">HOW IT WORKS</div>
            <h2 class="section-title">The Training Process</h2>
        </div>
        <div class="process-steps">
            <?php
            $steps = [
                ['num' => '01', 'icon' => 'ph-chats', 'title' => 'Discovery Call', 'desc' => 'We discuss your team\'s current skill level, goals, timeline, and infrastructure context.'],
                ['num' => '02', 'icon' => 'ph-pencil-ruler', 'title' => 'Curriculum Design', 'desc' => 'I build or adapt a custom training plan with lab environments for your specific stack.'],
                ['num' => '03', 'icon' => 'ph-chalkboard-teacher', 'title' => 'Training Delivery', 'desc' => 'Interactive, hands-on sessions delivered live (remote or on-site) with real lab work.'],
                ['num' => '04', 'icon' => 'ph-chart-bar', 'title' => 'Assessment & Report', 'desc' => 'Post-training evaluations and a detailed competency report for your organization.'],
            ];
            foreach ($steps as $i => $step): ?>
                <div class="process-step" id="process-step-<?= $i ?>">
                    <div class="process-step-num">
                        <?= $step['num'] ?>
                    </div>
                    <div class="process-step-icon">
                        <i class="ph <?= $step['icon'] ?>"></i>
                    </div>
                    <h3>
                        <?= $step['title'] ?>
                    </h3>
                    <p>
                        <?= $step['desc'] ?>
                    </p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section cta-banner" id="services-cta">
    <div class="container">
        <div class="cta-banner-inner">
            <div>
                <h2 class="cta-banner-title">Let's build something together.</h2>
                <p class="cta-banner-sub">Start with a free discovery call — no commitment required.</p>
            </div>
            <a href="?page=contact" class="btn btn-primary btn-lg" id="services-cta-btn">
                <i class="ph ph-calendar-check"></i> Book a Training Session
            </a>
        </div>
    </div>
</section>