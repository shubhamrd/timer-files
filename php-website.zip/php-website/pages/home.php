<?php
// pages/home.php
?>
<!-- ======= HERO SECTION ======= -->
<section class="hero" id="hero">
    <div class="hero-bg-grid"></div>
    <div class="hero-orb hero-orb--1"></div>
    <div class="hero-orb hero-orb--2"></div>

    <div class="hero-container">
        <div class="hero-content">
            <div class="hero-badge" id="hero-badge">
                <span class="badge-dot"></span>
                Available for Corporate Training &amp; Consulting
            </div>
            <h1 class="hero-title" id="hero-title">
                Empowering Teams through<br>
                <span class="hero-title-gradient">Cloud, Container,</span><br>
                and AI Infrastructure Training
            </h1>
            <p class="hero-subtitle" id="hero-subtitle">
                Corporate Technical Trainer · Cloud Solution Architect Associate · Microsoft Copilot Moderator.
                Delivering hands-on, impact-driven training across AWS, GCP, Azure, Docker, and Kubernetes.
            </p>
            <div class="hero-actions" id="hero-actions">
                <a href="?page=contact" class="btn btn-primary btn-lg" id="hero-cta-primary">
                    <i class="ph ph-calendar-check"></i>
                    Book a Training Session
                </a>
                <a href="?page=services" class="btn btn-ghost btn-lg" id="hero-cta-secondary">
                    Explore Services
                    <i class="ph ph-arrow-right"></i>
                </a>
            </div>
            <div class="hero-stats" id="hero-stats">
                <div class="stat-item">
                    <span class="stat-number">5+</span>
                    <span class="stat-label">Years Experience</span>
                </div>
                <div class="stat-divider"></div>
                <div class="stat-item">
                    <span class="stat-number">3</span>
                    <span class="stat-label">Cloud Platforms</span>
                </div>
                <div class="stat-divider"></div>
                <div class="stat-item">
                    <span class="stat-number">100+</span>
                    <span class="stat-label">Professionals Trained</span>
                </div>
            </div>
        </div>
        <div class="hero-visual" id="hero-visual">
            <div class="avatar-wrapper">
                <div class="avatar-ring avatar-ring--outer"></div>
                <div class="avatar-ring avatar-ring--inner"></div>
                <div class="avatar-frame">
                    <img src="assets/images/avatar.png" alt="Shubham D. — Cloud &amp; Containerization Trainer"
                        class="avatar-img" id="hero-avatar">
                    <div class="avatar-glow"></div>
                </div>
                <!-- Floating tech badges -->
                <div class="tech-badge tech-badge--aws" id="badge-aws">
                    <img src="assets/images/icons/aws.svg" alt="AWS">
                    <span>AWS</span>
                </div>
                <div class="tech-badge tech-badge--k8s" id="badge-k8s">
                    <img src="assets/images/icons/k8s.svg" alt="Kubernetes">
                    <span>K8s</span>
                </div>
                <div class="tech-badge tech-badge--docker" id="badge-docker">
                    <img src="assets/images/icons/docker.svg" alt="Docker">
                    <span>Docker</span>
                </div>
                <div class="tech-badge tech-badge--az" id="badge-az">
                    <img src="assets/images/icons/azure.svg" alt="Azure">
                    <span>Azure</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Scroll indicator -->
    <div class="scroll-indicator" id="scroll-indicator">
        <span>Scroll</span>
        <div class="scroll-line"></div>
    </div>
</section>

<!-- ======= ABOUT SNIPPET ======= -->
<section class="section about-snippet" id="about-snippet">
    <div class="container">
        <div class="about-snippet-inner">
            <div class="about-snippet-text">
                <div class="section-label">WHO I AM</div>
                <h2 class="section-title">Technical Trainer.<br>Cloud Architect. Innovator.</h2>
                <p class="section-body">
                    I'm a Software Engineer turned Corporate Technical Trainer, passionate about making
                    complex cloud and container technologies accessible to engineering teams at every level.
                    With hands-on experience across AWS, GCP, and Azure, I design training programs that
                    bridge theory with real-world production environments.
                </p>
                <a href="?page=about" class="btn btn-outline" id="about-snippet-cta">
                    Learn More About Me <i class="ph ph-arrow-right"></i>
                </a>
            </div>
            <div class="about-snippet-cards">
                <?php
                $roles = [
                    ['icon' => 'ph-cloud', 'title' => 'Cloud Solution Architect Associate', 'desc' => 'Architecting scalable solutions on AWS, Azure &amp; GCP.'],
                    ['icon' => 'ph-robot', 'title' => 'Microsoft Copilot Moderator', 'desc' => 'Guiding enterprise teams in responsible AI adoption.'],
                    ['icon' => 'ph-chalkboard-teacher', 'title' => 'Corporate Technical Trainer', 'desc' => 'Delivering immersive, lab-driven training programs.'],
                ];
                foreach ($roles as $i => $role): ?>
                    <div class="role-card" id="role-card-<?= $i ?>">
                        <div class="role-card-icon">
                            <i class="ph <?= $role['icon'] ?>"></i>
                        </div>
                        <div class="role-card-body">
                            <h3>
                                <?= $role['title'] ?>
                            </h3>
                            <p>
                                <?= $role['desc'] ?>
                            </p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- ======= SERVICES SNIPPET ======= -->
<section class="section services-snippet" id="services-snippet">
    <div class="container">
        <div class="section-header centered">
            <div class="section-label">CORE EXPERTISE</div>
            <h2 class="section-title">What I Deliver</h2>
            <p class="section-body">Curriculum-backed, hands-on training that transforms how engineering teams think
                about infrastructure.</p>
        </div>
        <div class="services-grid" id="services-grid">
            <?php
            $services = [
                [
                    'id' => 'cloud',
                    'icon' => 'ph-cloud-lightning',
                    'color' => 'blue',
                    'title' => 'Cloud Platforms',
                    'desc' => 'Deep-dive training across AWS, GCP, and Azure — from core concepts to production-grade architecture.',
                    'tags' => ['AWS', 'GCP', 'Azure', 'IAM', 'VPC', 'Serverless'],
                ],
                [
                    'id' => 'containers',
                    'icon' => 'ph-package',
                    'color' => 'teal',
                    'title' => 'Containerization',
                    'desc' => 'Hands-on Docker and Kubernetes workshops covering orchestration, networking, security, and CI/CD pipelines.',
                    'tags' => ['Docker', 'Kubernetes', 'Helm', 'CI/CD', 'Namespaces'],
                ],
                [
                    'id' => 'curriculum',
                    'icon' => 'ph-book-open-text',
                    'color' => 'purple',
                    'title' => 'Curriculum Design',
                    'desc' => 'Custom lab guides, step-by-step instructions, and corporate evaluations tailored to team maturity and goals.',
                    'tags' => ['Lab Guides', 'Assessments', 'Workshops', 'Custom LMS'],
                ],
                [
                    'id' => 'ai',
                    'icon' => 'ph-brain',
                    'color' => 'orange',
                    'title' => 'AI Infrastructure',
                    'desc' => 'Upcoming training modules in MLOps, Agentic AI, and AI workloads on Kubernetes — the next frontier.',
                    'tags' => ['MLOps', 'Agentic AI', 'LLM Infra', 'AI on K8s'],
                    'badge' => 'Coming Soon',
                ],
            ];
            foreach ($services as $i => $svc): ?>
                <div class="service-card service-card--<?= $svc['color'] ?>" id="service-card-<?= $svc['id'] ?>">
                    <?php if (!empty($svc['badge'])): ?>
                        <span class="service-badge">
                            <?= $svc['badge'] ?>
                        </span>
                    <?php endif; ?>
                    <div class="service-card-icon service-icon--<?= $svc['color'] ?>">
                        <i class="ph <?= $svc['icon'] ?>"></i>
                    </div>
                    <h3 class="service-card-title">
                        <?= $svc['title'] ?>
                    </h3>
                    <p class="service-card-desc">
                        <?= $svc['desc'] ?>
                    </p>
                    <div class="service-tags">
                        <?php foreach ($svc['tags'] as $tag): ?>
                            <span class="tag">
                                <?= $tag ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="centered" style="margin-top:3rem;">
            <a href="?page=services" class="btn btn-outline" id="services-snippet-cta">View All Services <i
                    class="ph ph-arrow-right"></i></a>
        </div>
    </div>
</section>

<!-- ======= AI FUTURE SECTION ======= -->
<section class="section ai-future" id="ai-future">
    <div class="ai-future-glow"></div>
    <div class="container">
        <div class="ai-future-inner">
            <div class="ai-future-content">
                <div class="section-label">FUTURE FOCUS</div>
                <h2 class="section-title">The Next Frontier:<br><span class="hero-title-gradient">AI Infrastructure
                        Training</span></h2>
                <p class="section-body">
                    The intersection of container orchestration and AI workloads is where the industry is heading.
                    I'm actively researching and building training modules that marry Kubernetes &amp; Docker
                    with cutting-edge AI infrastructure — preparing teams before demand peaks.
                </p>
                <ul class="ai-pillars" id="ai-pillars">
                    <li><i class="ph ph-check-circle"></i> MLOps pipelines on Kubernetes</li>
                    <li><i class="ph ph-check-circle"></i> Deploying LLMs at scale with Docker</li>
                    <li><i class="ph ph-check-circle"></i> Agentic AI system architecture</li>
                    <li><i class="ph ph-check-circle"></i> GPU node management &amp; scheduling</li>
                    <li><i class="ph ph-check-circle"></i> AI workload security &amp; observability</li>
                </ul>
                <a href="?page=contact" class="btn btn-primary" id="ai-future-cta">
                    <i class="ph ph-lightning"></i> Get Early Access
                </a>
            </div>
            <div class="ai-future-visual">
                <div class="ai-terminal" id="ai-terminal">
                    <div class="terminal-header">
                        <span class="terminal-dot dot-red"></span>
                        <span class="terminal-dot dot-yellow"></span>
                        <span class="terminal-dot dot-green"></span>
                        <span class="terminal-title">kubectl apply</span>
                    </div>
                    <div class="terminal-body" id="terminal-body">
                        <div class="terminal-line"><span class="t-prompt">$</span> kubectl apply -f ai-workload.yaml
                        </div>
                        <div class="terminal-line t-success">namespace/mlops created</div>
                        <div class="terminal-line t-success">deployment.apps/llm-inference created</div>
                        <div class="terminal-line t-success">service/inference-svc created</div>
                        <div class="terminal-line"><span class="t-prompt">$</span> kubectl get pods -n mlops</div>
                        <div class="terminal-line t-info">
                            NAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            READY&nbsp;&nbsp;STATUS</div>
                        <div class="terminal-line t-success">
                            llm-inference-xxx&nbsp;&nbsp;1/1&nbsp;&nbsp;&nbsp;&nbsp;Running</div>
                        <div class="terminal-line t-muted">
                            agent-runner-xxx&nbsp;&nbsp;&nbsp;1/1&nbsp;&nbsp;&nbsp;&nbsp;Running</div>
                        <div class="terminal-line blink-cursor"><span class="t-prompt">$</span> <span
                                class="cursor">█</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ======= CTA BANNER ======= -->
<section class="section cta-banner" id="cta-banner">
    <div class="container">
        <div class="cta-banner-inner">
            <div>
                <h2 class="cta-banner-title">Ready to upskill your team?</h2>
                <p class="cta-banner-sub">Let's design a training program that fits your team's needs and goals.</p>
            </div>
            <div class="cta-banner-actions">
                <a href="?page=contact" class="btn btn-primary btn-lg" id="banner-cta">
                    <i class="ph ph-calendar-check"></i> Book a Training Session
                </a>
            </div>
        </div>
    </div>
</section>