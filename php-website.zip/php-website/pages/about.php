<?php // pages/about.php ?>
<section class="page-hero" id="about-hero">
    <div class="hero-bg-grid"></div>
    <div class="container">
        <div class="section-label">ABOUT ME</div>
        <h1 class="page-hero-title">The Person Behind the Training</h1>
        <p class="page-hero-sub">Software Engineer. Corporate Trainer. Cloud Architect. Road-trip enthusiast from
            Sangamner.</p>
    </div>
</section>

<section class="section about-full" id="about-full">
    <div class="container">
        <div class="about-full-grid">
            <!-- Bio Card -->
            <div class="about-bio-card" id="about-bio-card">
                <div class="about-avatar-wrap">
                    <img src="assets/images/avatar.png" alt="Shubham D." class="about-avatar">
                    <div class="about-avatar-glow"></div>
                </div>
                <div class="about-bio-text">
                    <h2 class="about-name">Shubham D.</h2>
                    <p class="about-role">Cloud & Containerization Corporate Trainer</p>
                    <div class="about-location">
                        <i class="ph ph-map-pin"></i>
                        <span>Sangamner, Maharashtra, India</span>
                    </div>
                    <div class="about-socials">
                        <a href="https://linkedin.com/in/shubhamd" target="_blank" rel="noopener" class="social-link"
                            id="about-linkedin">
                            <i class="ph ph-linkedin-logo"></i> LinkedIn
                        </a>
                        <a href="https://github.com/shubhamd" target="_blank" rel="noopener" class="social-link"
                            id="about-github">
                            <i class="ph ph-github-logo"></i> GitHub
                        </a>
                    </div>
                </div>
            </div>

            <!-- Story -->
            <div class="about-story" id="about-story">
                <div class="section-label">MY STORY</div>
                <h2 class="section-title">From Engineering Code<br>to Engineering Minds</h2>
                <p class="section-body">
                    My journey began as a Software Engineer, building systems and solving problems at the code level.
                    But I quickly discovered that my greatest impact wasn't in the code I wrote — it was in the
                    knowledge
                    I transferred. That realization set me on a path toward corporate training, where I now help
                    engineering
                    teams across organizations master the technologies that power modern infrastructure.
                </p>
                <p class="section-body">
                    Today, I wear multiple hats: <strong>Cloud Solution Architect Associate</strong>, designing scalable
                    cloud architectures; <strong>Microsoft Copilot Moderator</strong>, helping enterprises navigate
                    responsible AI adoption; and above all, a <strong>Corporate Technical Trainer</strong>, delivering
                    hands-on, lab-driven sessions that bridge theoretical knowledge with real production environments.
                </p>
                <p class="section-body">
                    When I'm not designing curriculum or running workshops, you'll find me on the open road — a proud
                    road
                    trip enthusiast who finds clarity and creativity in the journey between destinations.
                    Based in the beautiful city of Sangamner, Maharashtra, I believe that great training,
                    like a great road trip, is all about the experience, not just the destination.
                </p>

                <!-- Certifications -->
                <div class="certs-row" id="certs-row">
                    <?php
                    $certs = [
                        ['icon' => 'ph-seal-check', 'label' => 'AWS Certified', 'color' => 'orange'],
                        ['icon' => 'ph-seal-check', 'label' => 'Azure Certified', 'color' => 'blue'],
                        ['icon' => 'ph-seal-check', 'label' => 'GCP Certified', 'color' => 'teal'],
                        ['icon' => 'ph-seal-check', 'label' => 'MS Copilot Moderator', 'color' => 'purple'],
                    ];
                    foreach ($certs as $i => $cert): ?>
                        <div class="cert-chip cert-chip--<?= $cert['color'] ?>" id="cert-<?= $i ?>">
                            <i class="ph <?= $cert['icon'] ?>"></i>
                            <span>
                                <?= $cert['label'] ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Values / Philosophy -->
        <div class="values-section" id="values-section">
            <div class="section-header centered">
                <div class="section-label">MY PHILOSOPHY</div>
                <h2 class="section-title">How I Approach Training</h2>
            </div>
            <div class="values-grid">
                <?php
                $values = [
                    ['icon' => 'ph-hands-clapping', 'color' => 'blue', 'title' => 'Hands-On First', 'desc' => 'Every session includes real labs that mirror production scenarios. No slide-only theory.'],
                    ['icon' => 'ph-target', 'color' => 'teal', 'title' => 'Outcome-Driven', 'desc' => 'Training is designed around measurable competency outcomes, not just coverage of topics.'],
                    ['icon' => 'ph-users-three', 'color' => 'purple', 'title' => 'Team-Calibrated', 'desc' => 'Content and pacing are adapted to the existing skill level and goals of each team.'],
                    ['icon' => 'ph-trend-up', 'color' => 'orange', 'title' => 'Future-Aware', 'desc' => 'I constantly update curriculum to reflect industry trends — especially at the AI infrastructure frontier.'],
                ];
                foreach ($values as $i => $v): ?>
                    <div class="value-card" id="value-card-<?= $i ?>">
                        <div class="value-icon value-icon--<?= $v['color'] ?>">
                            <i class="ph <?= $v['icon'] ?>"></i>
                        </div>
                        <h3>
                            <?= $v['title'] ?>
                        </h3>
                        <p>
                            <?= $v['desc'] ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- CTA Strip -->
<section class="section cta-banner" id="about-cta">
    <div class="container">
        <div class="cta-banner-inner">
            <div>
                <h2 class="cta-banner-title">Let's work together.</h2>
                <p class="cta-banner-sub">Have a training requirement? Let's design something remarkable.</p>
            </div>
            <a href="?page=contact" class="btn btn-primary btn-lg" id="about-cta-btn">
                <i class="ph ph-calendar-check"></i> Book a Session
            </a>
        </div>
    </div>
</section>