# 🌐 PHP Portfolio Website

A modern, dark-themed personal portfolio website built with **PHP 8.4**, designed for hosting at [shubhamd.com](https://shubhamd.com). The site communicates technical authority, clarity, and innovation through a premium developer-tool aesthetic.

---

## 📁 Project Structure

```
php-website/
├── index.php               # Main entry point — handles routing & form submission
├── .htaccess               # Apache config: URL rewriting, caching, security headers
│
├── pages/                  # Page content files (loaded dynamically via index.php)
│   ├── home.php            # Hero section, intro, and featured highlights
│   ├── about.php           # About Me — background, skills, and experience
│   ├── services.php        # Core Expertise & Services offered
│   └── contact.php         # Contact form and booking section
│
├── includes/               # Reusable PHP partials
│   ├── head.php            # HTML <head> — meta tags, CSS links, fonts
│   ├── nav.php             # Top navigation bar
│   └── footer.php          # Site footer
│
└── assets/                 # Static assets
    ├── css/                # Stylesheets
    ├── js/                 # JavaScript files
    └── images/             # Images (PNG, WebP, SVG)
```

---

## ⚙️ How It Works

The site uses a **single entry point** pattern:

- All requests go through `index.php`
- A `?page=` query parameter determines which page to render (e.g., `?page=about`)
- Allowed pages: `home`, `about`, `services`, `contact`
- Invalid page values fall back to `home`
- The contact form is handled server-side within `index.php` via `$_POST`

---

## 🚀 Getting Started

### Requirements
- PHP 8.4+
- Apache with `mod_rewrite`, `mod_expires`, `mod_deflate`, `mod_headers` enabled

### Local Development

1. Clone or download the project into your Apache web root (e.g., `htdocs/` or `www/`)
2. Make sure Apache's `mod_rewrite` is enabled
3. Visit `http://localhost/php-website/` in your browser

### Production Deployment

1. Upload all files to your server's public web root
2. Uncomment the HTTPS redirect in `.htaccess`:
   ```apache
   RewriteCond %{HTTPS} off
   RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
   ```
3. Set up an SMTP library or configure `mail()` in `index.php` for contact form emails
4. Ensure `display_errors` is `Off` (already set in `.htaccess` for PHP via `mod_php`)

---

## 🔒 Security & Performance

The `.htaccess` file includes several production-ready configurations:

| Feature              | Detail                                                 |
|----------------------|--------------------------------------------------------|
| Directory listing    | Disabled (`Options -Indexes`)                          |
| HTTPS redirect       | Commented out — enable on production                   |
| Static asset caching | Images: 1 year · CSS/JS: 1 month                       |
| Gzip compression     | Enabled for HTML, CSS, JS, and plain text              |
| Security headers     | `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy` |
| PHP settings         | `upload_max_filesize` and `post_max_size` set to 10M   |

---

## 📄 Pages Overview

| Page       | File                  | Description                                         |
|------------|-----------------------|-----------------------------------------------------|
| Home       | `pages/home.php`      | Hero section, tagline, and featured highlights      |
| About      | `pages/about.php`     | Personal background, skills, and work experience    |
| Services   | `pages/services.php`  | Core expertise, service offerings, and AI focus     |
| Contact    | `pages/contact.php`   | Contact/booking form with server-side validation    |

---

## 🛠️ Tech Stack

- **Backend:** PHP 8.4
- **Server:** Apache (with `.htaccess`)
- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **Hosting Target:** [shubhamd.com](https://shubhamd.com)

---

## 📬 Contact Form

The contact form (`pages/contact.php`) currently uses basic PHP validation and sets a success/error flag. To send actual emails in production, update `index.php` with either:

- PHP's built-in `mail()` function
- An SMTP library like [PHPMailer](https://github.com/PHPMailer/PHPMailer) or [SwiftMailer](https://swiftmailer.symfony.com/)

---

*Last updated: March 2026*
